<h1 align="center">Roblox Cookie Login Extension</h1>
<h2 align="center">This extension can login to Roblox using a .ROBLOSECURITY cookie value</h2>

---

1. Copy the `.ROBLOSECURITY` Roblox cookie of the account you want to login to
2. Paste it in where it says `Enter a cookie...`
3. Press `Set Cookie` button and refresh the page

---

![image](https://github.com/user-attachments/assets/1e56f769-d7e3-4b83-b68f-2cbbea35cb8f)

---

### ⚙️ Setup
1. Download and unzip the folder
2. Go to the extensions path of your browser
3. Press **Load unpacked** button and select the unzipped folder
4. Enable the extension and you're done!

![image](https://github.com/user-attachments/assets/a8e0e408-6f5f-4bc7-b9e5-9cae0f64c007)

---

### 🚨 Disclaimer
This is meant to be used for educational purposes only. I am not responsible for the actions users take upon using this extension.

---

This project was inspired by Nick, founder of INJURIES
